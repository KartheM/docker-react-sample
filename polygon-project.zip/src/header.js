import React from 'react';
import {  Link } from "react-router-dom";
const Header= () =>{
  return (
  <div>
    <li>
      <Link to="/">Zone 1</Link>
    </li>
    <li>
      <Link to="/cats">Zone 2</Link>
    </li>
    <li>
      <Link to="/sheeps">Zone 3</Link>
    </li>
  </div>
  );
}
export default Header;