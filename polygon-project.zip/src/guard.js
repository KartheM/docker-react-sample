// @flow
import React from "react";
import { StyleSheet, css } from "aphrodite";
import ReactDOM from "react-dom";
import Polygon from "react-polygon";
import Draggable from "react-draggable";
import Header from "./header"
import Navbar from './nav';
import {
  Menu,
  MenuItem
} from "react-pro-sidebar";

type Props = {};

type State = {
  highlight: boolean
};

export default class GuardCircle extends React.Component<Props, State> {
  constructor(props) {
    super(props);
    this.state = {
      highlight: false,
      polygonHighlight: false,
      data: [
        [
          [10,20],
          [20,290],
          [20,60],
          [90,300],
          [100,120],
          [130,220]
        ],
        [
          [100,20],
          [200,290],
          [200,60],
          [900,300]
        ],
        [
          [200, 300],
          [200, 300],
          [20, 90],
          [20, 90]
        ],
        [[0.9875, 0.9826], [0.9875, 0.5609], [0.5958, 0.5609], [0.5958, 0.9826]],
        [[0.4813, 0.0804], [0.025, 0.0804], [0.025, 0.2174], [0.4813, 0.2174]],
        [[0.9812, 0.2065], [0.9812, 0.0804], [0.6, 0.0804], [0.6, 0.2065]],
        [
          [0.9896, 0.5543],
          [0.9896, 0.3848],
          [0.7729, 0.3848],
          [0.7729, 0.2652],
          [0.5979, 0.2652],
          [0.5979, 0.5543]
        ],
        [[0.4792, 0.587], [0.4792, 0.2696], [0.2854, 0.2696], [0.2854, 0.587]]
      ]
    };
  }

  isGuardWithinBounds(x, y) {
    if (x <= 250 && x >= 160 && y <= 210 && y >= 10) {
      return true;
    }
    return false;
  }
  render() {
    const circle = (
      <div className={css([this.state.highlight && styles.outerCircle])}>
        <div className={css([styles.innerCircle])} />
      </div>
    );


 
    const triangle = (
      <svg height="1000" width="1000">
     
          {
           this.state.data.map(function(data, i){
          
            data.flat();
            console.log(data.join(' ').toString());
             return <polygon
             points={data.join(' ').toString()}
             stroke="black" 
             ondragover={() => this.setState({ polygonHighlight: true })}
             style={{color:"red"}}
            //  className={css([
            //    styles.polygon,
            //    this.state.polygonHighlight && styles.polygonHighlight
            //  ])}
           />
           })
         }
      </svg>
    );

    const quadrilateral = (
      <svg height="210" width="500">
        <polygon
        stroke="black" 
          points="0.4813,0.9848 0.4813,0.5913 0.2271,0.5913 0.2271,0.3826 0.0292,0.3826 0.0271,0.9848"
          className={css([
            styles.polygon,
            this.state.polygonHighlight && styles.polygonHighlight
          ])}
        />
      </svg>
    );

    const quadrilateral2 = (
      <svg height="210" width="500">
        <polygon
          points="10,60 80,110 160,30 250,290"
          className={css([
            styles.polygon,
            this.state.polygonHighlight && styles.polygonHighlight
          ])}
        />
      </svg>
    );
    const sidebar = 
    <Menu iconShape="square">
        <MenuItem>Component 1</MenuItem>
        <MenuItem>Component 2</MenuItem>
    </Menu>;

    return (
      <div>
        {/* <Header/> */}
        {/* {sidebar} */}
        {triangle}
        {/* <Draggable
          onMouseDown={e => {
            if (this.isGuardWithinBounds(e.clientX, e.clientY)) {
              this.setState({ polygonHighlight: true });
            } else {
              this.setState({ polygonHighlight: false });
            }
          }}
          onStop={e => {
            if (this.isGuardWithinBounds(e.clientX, e.clientY)) {
              this.setState({ polygonHighlight: true });
            } else {
              this.setState({ polygonHighlight: false });
            }
          }}
        >
          {circle}
        </Draggable> */}
      </div>
    );
  }
}

const styles = StyleSheet.create({
  innerCircle: {
    borderRadius: "50%",
    width: 15,
    height: 15,
    // margin: 5,
    backgroundColor: "black"
  },
  polygon: {
    fill: "#2E8B57",
    opacity: 0.5,
    ":hover": {
      fill: "blue"
    }
  },
  polygonHighlight: {
    fill: "red"
  }
});
